import { logger } from './logger';
import type { ClassificationRecord, ContextMemory, Correction } from '@/types/screenplay';
import type { DialogueBlock, LineRelation } from './classification-core';
import { detectPattern } from './classification-core';
import { safeGetItem, safeSetItem, saveJSON, loadJSON } from './storage';

export type { ClassificationRecord, ContextMemory };

/**
 * ذاكرة السياق المحسّنة - Enhanced Context Memory
 * تضيف: كتل الحوار، علاقات الأسطر، تصحيحات المستخدم، خريطة الثقة
 */
export interface EnhancedContextMemory extends ContextMemory {
  data: ContextMemory['data'] & {
    dialogueBlocks: DialogueBlock[];
    lineRelationships: LineRelation[];
    userCorrections: Correction[];
    confidenceMap: { [line: string]: number };
  };
}

/**
 * Context Memory Manager المحسّن
 * يدعم: localStorage، كتل الحوار، كشف الأنماط، تصحيحات المستخدم
 */
export class ContextMemoryManager {
  private storage: Map<string, EnhancedContextMemory> = new Map();

  constructor() {
    logger.info('ContextMemoryManager initialized (enhanced).', { component: 'MemoryManager' });
  }

  async loadContext(sessionId: string): Promise<EnhancedContextMemory | null> {
    // أولاً: حاول التحميل من الذاكرة
    if (this.storage.has(sessionId)) {
      logger.info(`Loading context for session: ${sessionId}`, { component: 'MemoryManager' });
      return JSON.parse(JSON.stringify(this.storage.get(sessionId)!));
    }

    // ثانياً: حاول التحميل من localStorage
    const loaded = this.loadFromLocalStorage(sessionId);
    if (loaded) {
      this.storage.set(sessionId, loaded);
      return loaded;
    }

    logger.warn(`No context found for session: ${sessionId}`, { component: 'MemoryManager' });
    return null;
  }

  async saveContext(sessionId: string, memory: EnhancedContextMemory | ContextMemory): Promise<void> {
    logger.info(`Saving context for session: ${sessionId}`, { component: 'MemoryManager' });

    // تحويل ContextMemory العادي إلى Enhanced إذا لزم الأمر
    const enhanced = this.ensureEnhanced(memory);
    this.storage.set(sessionId, JSON.parse(JSON.stringify(enhanced)));

    // حفظ في localStorage
    this.saveToLocalStorage(sessionId);
  }

  async updateMemory(sessionId: string, classifications: ClassificationRecord[]): Promise<void> {
    logger.info(`Updating memory for session ${sessionId} with ${classifications.length} records.`, { component: 'MemoryManager' });

    const existing = await this.loadContext(sessionId);
    const memory: EnhancedContextMemory = existing || this.createDefaultMemory(sessionId);

    memory.lastModified = Date.now();
    memory.data.lastClassifications = classifications
      .map((c) => c.classification)
      .concat(memory.data.lastClassifications)
      .slice(0, 20);

    classifications.forEach((record) => {
      if (record.classification === 'character') {
        const charName = record.line.replace(/[:：]/g, '').trim();
        if (charName) {
          if (!memory.data.commonCharacters.includes(charName)) {
            memory.data.commonCharacters.push(charName);
          }
          memory.data.characterDialogueMap[charName] =
            (memory.data.characterDialogueMap[charName] || 0) + 1;
        }
      }
    });

    await this.saveContext(sessionId, memory);
  }

  // ===== ميزات جديدة =====

  /** حفظ في localStorage */
  saveToLocalStorage(sessionId: string): void {
    const memory = this.storage.get(sessionId);
    if (!memory) return;

    const key = `screenplay-memory-${sessionId}`;
    saveJSON(key, memory);
  }

  /** تحميل من localStorage */
  loadFromLocalStorage(sessionId: string): EnhancedContextMemory | null {
    const key = `screenplay-memory-${sessionId}`;
    const parsed = loadJSON<EnhancedContextMemory | null>(key, null);
    if (parsed) {
      return this.ensureEnhanced(parsed);
    }
    return null;
  }

  /** تتبع كتلة حوار */
  trackDialogueBlock(sessionId: string, character: string, startLine: number, endLine: number): void {
    const memory = this.storage.get(sessionId);
    if (!memory) return;

    const block: DialogueBlock = {
      character,
      startLine,
      endLine,
      lineCount: endLine - startLine + 1,
    };

    memory.data.dialogueBlocks.push(block);

    // الاحتفاظ بأحدث 50 كتلة فقط
    if (memory.data.dialogueBlocks.length > 50) {
      memory.data.dialogueBlocks = memory.data.dialogueBlocks.slice(-50);
    }

    this.saveToLocalStorage(sessionId);
  }

  /** إضافة علاقة بين سطرين */
  addLineRelation(sessionId: string, relation: LineRelation): void {
    const memory = this.storage.get(sessionId);
    if (!memory) return;

    memory.data.lineRelationships.push(relation);

    if (memory.data.lineRelationships.length > 200) {
      memory.data.lineRelationships = memory.data.lineRelationships.slice(-200);
    }

    this.saveToLocalStorage(sessionId);
  }

  /** كشف نمط متكرر - uses shared detectPattern with 'newest-first' order */
  detectPattern(sessionId: string): string | null {
    const memory = this.storage.get(sessionId);
    if (!memory) return null;

    // Use shared detectPattern with 'newest-first' since lastClassifications is stored newest-first
    return detectPattern(memory.data.lastClassifications, 'newest-first');
  }

  /** إضافة تصحيح من المستخدم */
  addUserCorrection(sessionId: string, correction: Correction): void {
    const memory = this.storage.get(sessionId);
    if (!memory) return;

    memory.data.userCorrections.push(correction);

    // الاحتفاظ بأحدث 200 تصحيح
    if (memory.data.userCorrections.length > 200) {
      memory.data.userCorrections = memory.data.userCorrections.slice(-200);
    }

    this.saveToLocalStorage(sessionId);
  }

  /** الحصول على تصحيحات المستخدم */
  getUserCorrections(sessionId: string): Correction[] {
    const memory = this.storage.get(sessionId);
    return memory?.data.userCorrections || [];
  }

  /** تحديث ثقة التصنيف */
  updateConfidence(sessionId: string, line: string, confidence: number): void {
    const memory = this.storage.get(sessionId);
    if (!memory) return;

    memory.data.confidenceMap[line] = confidence;

    this.saveToLocalStorage(sessionId);
  }

  // ===== أدوات داخلية =====

  private createDefaultMemory(sessionId: string): EnhancedContextMemory {
    return {
      sessionId,
      lastModified: Date.now(),
      data: {
        commonCharacters: [],
        commonLocations: [],
        lastClassifications: [],
        characterDialogueMap: {},
        dialogueBlocks: [],
        lineRelationships: [],
        userCorrections: [],
        confidenceMap: {},
      },
    };
  }

  private ensureEnhanced(memory: ContextMemory | EnhancedContextMemory): EnhancedContextMemory {
    const data = memory.data as EnhancedContextMemory['data'];
    return {
      ...memory,
      data: {
        ...memory.data,
        dialogueBlocks: data.dialogueBlocks || [],
        lineRelationships: data.lineRelationships || [],
        userCorrections: data.userCorrections || [],
        confidenceMap: data.confidenceMap || {},
      },
    };
  }
}
