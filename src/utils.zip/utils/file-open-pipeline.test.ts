import { describe, expect, it } from "vitest";
import type { FileExtractionResult } from "@/types/file-import";
import { buildFileOpenPipelineAction } from "./file-open-pipeline";

const baseExtraction = (
  overrides: Partial<FileExtractionResult>
): FileExtractionResult => ({
  text: "",
  fileType: "docx",
  method: "mammoth",
  usedOcr: false,
  warnings: [],
  attempts: ["mammoth"],
  ...overrides,
});

describe("buildFileOpenPipelineAction", () => {
  it("returns classified import action when extracted blocks and text are present", () => {
    const action = buildFileOpenPipelineAction(
      baseExtraction({
        method: "app-payload",
        text: "مشهد 1\nوصف الحدث",
        structuredBlocks: [
          { formatId: "scene-header-1", text: "مشهد 1" },
          { formatId: "action", text: "وصف الحدث" },
        ],
      }),
      "replace"
    );

    expect(action.kind).toBe("import-classified-text");
    if (action.kind !== "import-classified-text") return;
    expect(action.text).toContain("مشهد 1");
    expect(action.toast.description).toContain("تم تطبيق تصنيف اللصق");
    expect(action.toast.description).toContain("payload");
    expect(action.telemetry.openPipeline).toBe("paste-classifier");
    expect(action.telemetry.source).toBe("structured-blocks");
  });

  it("falls back to structured blocks text when extraction text is empty", () => {
    const action = buildFileOpenPipelineAction(
      baseExtraction({
        text: "",
        fileType: "doc",
        structuredBlocks: [
          { formatId: "scene-header-1", text: "مشهد1" },
          { formatId: "action", text: "وصف" },
        ],
      }),
      "replace"
    );

    expect(action.kind).toBe("import-classified-text");
    if (action.kind !== "import-classified-text") return;
    expect(action.text).toContain("مشهد1");
    expect(action.telemetry.source).toBe("structured-blocks");
    expect(action.telemetry.preprocessedSteps.length).toBeGreaterThan(0);
  });

  it("rejects empty extraction text with destructive toast", () => {
    const action = buildFileOpenPipelineAction(
      baseExtraction({
        text: "   ",
        structuredBlocks: undefined,
      }),
      "insert"
    );

    expect(action.kind).toBe("reject");
    if (action.kind !== "reject") return;
    expect(action.toast.variant).toBe("destructive");
    expect(action.toast.title).toBe("ملف فارغ");
  });

  it("returns paste-like classified import action when text exists", () => {
    const action = buildFileOpenPipelineAction(
      baseExtraction({
        fileType: "doc",
        text: "مشهد1 داخلي - نهار",
        warnings: ["تنبيه اختباري"],
      }),
      "replace"
    );

    expect(action.kind).toBe("import-classified-text");
    if (action.kind !== "import-classified-text") return;
    expect(action.text).toContain("مشهد 1");
    expect(action.toast.description).toContain("تنبيه اختباري");
    expect(action.telemetry.preprocessedSteps.length).toBeGreaterThan(0);
  });
});
