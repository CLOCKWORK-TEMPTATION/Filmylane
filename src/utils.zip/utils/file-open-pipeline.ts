import type { FileExtractionResult, FileImportMode } from "@/types/file-import";
import { preprocessImportedTextForClassifier } from "./file-import-preprocessor";

type SuccessVariant = "default";
type ErrorVariant = "destructive";

type FileOpenToast = {
  title: string;
  description: string;
  variant?: SuccessVariant | ErrorVariant;
};

type FileOpenPipelineTelemetry = {
  openPipeline: "paste-classifier";
  method: FileExtractionResult["method"];
  source: "structured-blocks" | "extracted-text";
  usedOcr: boolean;
  qualityScore?: number;
  warnings: string[];
  preprocessedSteps: string[];
};

type ImportClassifiedAction = {
  kind: "import-classified-text";
  mode: FileImportMode;
  text: string;
  toast: FileOpenToast;
  telemetry: FileOpenPipelineTelemetry;
};

type RejectAction = {
  kind: "reject";
  mode: FileImportMode;
  toast: FileOpenToast & { variant: ErrorVariant };
  telemetry: FileOpenPipelineTelemetry;
};

export type FileOpenPipelineAction =
  | ImportClassifiedAction
  | RejectAction;

const buildModeLabel = (mode: FileImportMode): string =>
  mode === "replace" ? "تم فتح" : "تم إدراج";

const buildTelemetry = (
  extraction: FileExtractionResult,
  source: FileOpenPipelineTelemetry["source"],
  preprocessedSteps: string[]
): FileOpenPipelineTelemetry => ({
  openPipeline: "paste-classifier",
  method: extraction.method,
  source,
  usedOcr: extraction.usedOcr,
  qualityScore: extraction.qualityScore,
  warnings: extraction.warnings,
  preprocessedSteps,
});

export function buildFileOpenPipelineAction(
  extraction: FileExtractionResult,
  mode: FileImportMode
): FileOpenPipelineAction {
  const modeLabel = buildModeLabel(mode);
  const textFromBlocks = (extraction.structuredBlocks ?? [])
    .map((block) => block.text.trim())
    .filter(Boolean)
    .join("\n");
  const preferredSource: FileOpenPipelineTelemetry["source"] = textFromBlocks
    ? "structured-blocks"
    : "extracted-text";
  const sourceText =
    preferredSource === "structured-blocks"
      ? textFromBlocks
      : extraction.text;

  if (!sourceText.trim()) {
    return {
      kind: "reject",
      mode,
      toast: {
        title: "ملف فارغ",
        description: "لم يتم العثور على نص في الملف المحدد.",
        variant: "destructive",
      },
      telemetry: buildTelemetry(extraction, preferredSource, []),
    };
  }

  const preprocessed =
    preferredSource === "structured-blocks"
      ? {
          text: sourceText
            .replace(/\r\n/g, "\n")
            .replace(/\r/g, "\n")
            .trim(),
          applied: ["structured-blocks-text-normalization"],
        }
      : preprocessImportedTextForClassifier(sourceText, extraction.fileType);
  let description = `${modeLabel} الملف بنجاح\nتم تطبيق تصنيف اللصق`;
  if (extraction.usedOcr) {
    description += " (تم استخدام OCR)";
  }
  if (extraction.method === "app-payload") {
    description += "\n(تم تحويل payload إلى نص للتصنيف)";
  }
  if (preferredSource === "structured-blocks") {
    description += "\n(مصدر التصنيف: structured blocks)";
  }
  if (preprocessed.applied.length > 0) {
    description += `\n(تطبيع: ${preprocessed.applied.slice(0, 2).join(", ")})`;
  }
  if (extraction.warnings.length > 0) {
    description += `\n⚠️ ${extraction.warnings[0]}`;
  }

  return {
    kind: "import-classified-text",
    mode,
    text: preprocessed.text,
    toast: {
      title: modeLabel,
      description,
    },
    telemetry: buildTelemetry(extraction, preferredSource, preprocessed.applied),
  };
}
