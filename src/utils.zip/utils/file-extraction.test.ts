import { beforeEach, describe, expect, it, vi } from "vitest";

const {
  mammothExtractRawTextMock,
  isMistralConfiguredMock,
  extractTextWithMistralOcrMock,
  pdfLoadMock,
  pdfParseGetTextMock,
  pdfParseDestroyMock,
  execSyncMock,
  spawnSyncMock,
} = vi.hoisted(() => ({
  mammothExtractRawTextMock: vi.fn(),
  isMistralConfiguredMock: vi.fn(() => false),
  extractTextWithMistralOcrMock: vi.fn(),
  pdfLoadMock: vi.fn(),
  pdfParseGetTextMock: vi.fn(),
  pdfParseDestroyMock: vi.fn(async () => {}),
  execSyncMock: vi.fn(),
  spawnSyncMock: vi.fn(),
}));

vi.mock("mammoth", () => ({
  extractRawText: mammothExtractRawTextMock,
  default: {
    extractRawText: mammothExtractRawTextMock,
  },
}));

vi.mock("./mistral-ocr", () => ({
  isMistralConfigured: isMistralConfiguredMock,
  extractTextWithMistralOcr: extractTextWithMistralOcrMock,
}));

vi.mock("pdf-lib", () => ({
  PDFDocument: {
    load: pdfLoadMock,
  },
}));

vi.mock("pdf-parse", () => ({
  PDFParse: class PDFParseMock {
    constructor() {}
    async getText() {
      return pdfParseGetTextMock();
    }
    async destroy() {
      return pdfParseDestroyMock();
    }
  },
}));

vi.mock("child_process", () => ({
  execSync: execSyncMock,
  spawnSync: spawnSyncMock,
}));

import {
  buildPayloadMarker,
  createPayloadFromBlocks,
  encodeScreenplayPayload,
} from "./document-model";
import { extractFileText } from "./file-extraction";

describe("extractFileText", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    isMistralConfiguredMock.mockReturnValue(false);
    pdfLoadMock.mockResolvedValue({
      getSubject: () => null,
      getKeywords: () => [],
      getTitle: () => null,
      getProducer: () => null,
    });
    pdfParseGetTextMock.mockResolvedValue({
      text: "نص PDF محلي صالح للاستخدام",
    });
    execSyncMock.mockImplementation((command: string) => {
      if (String(command).includes("extract_doc.py")) {
        return "text from word com";
      }
      throw new Error("execSync mock: unknown command");
    });
    spawnSyncMock.mockReturnValue({
      status: 1,
      stdout: "",
      stderr: "spawn failed",
    });
  });

  it("extracts txt content", async () => {
    const result = await extractFileText(
      Buffer.from("مرحبا\nسطر ثاني"),
      "a.txt",
      "txt"
    );
    expect(result.method).toBe("native-text");
    expect(result.text).toContain("مرحبا");
    expect(result.usedOcr).toBe(false);
  });

  it("extracts app payload from docx marker", async () => {
    const payload = createPayloadFromBlocks([
      { formatId: "scene-header-1", text: "مشهد 1:" },
      { formatId: "action", text: "وصف" },
    ]);
    const marker = buildPayloadMarker(encodeScreenplayPayload(payload));
    mammothExtractRawTextMock.mockResolvedValueOnce({
      value: `محتوى\n${marker}\nنهاية`,
    });

    const result = await extractFileText(Buffer.from("x"), "b.docx", "docx");
    expect(result.method).toBe("app-payload");
    expect(result.payloadVersion).toBe(1);
    expect(result.structuredBlocks?.length).toBe(2);
    expect(result.structuredBlocks?.[0]?.formatId).toBe("scene-header-1");
  });

  it("extracts app payload from pdf metadata marker", async () => {
    const payload = createPayloadFromBlocks([
      { formatId: "character", text: "أحمد" },
      { formatId: "dialogue", text: "مرحبًا" },
    ]);
    const marker = buildPayloadMarker(encodeScreenplayPayload(payload));
    pdfLoadMock.mockResolvedValueOnce({
      getSubject: () => marker,
      getKeywords: () => [],
      getTitle: () => null,
      getProducer: () => null,
    });

    const result = await extractFileText(Buffer.from("pdf"), "c.pdf", "pdf");
    expect(result.method).toBe("app-payload");
    expect(result.structuredBlocks?.[0]?.formatId).toBe("character");
  });

  it("uses local pdf parser when payload not found and text is strong", async () => {
    const result = await extractFileText(Buffer.from("pdf"), "d.pdf", "pdf");
    expect(result.method).toBe("pdf-local");
    expect(result.usedOcr).toBe(false);
    expect(result.text).toContain("نص PDF محلي");
  });

  it("falls back to mistral OCR for weak pdf text", async () => {
    pdfParseGetTextMock.mockResolvedValueOnce({
      text: "ضعيف",
    });
    isMistralConfiguredMock.mockReturnValue(true);
    extractTextWithMistralOcrMock.mockResolvedValueOnce("OCR result");

    const result = await extractFileText(Buffer.from("pdf"), "e.pdf", "pdf");
    expect(result.method).toBe("ocr-mistral");
    expect(result.usedOcr).toBe(true);
    expect(result.text).toBe("OCR result");
  });

  it("tries windows antiword first for doc files", async () => {
    const result = await extractFileText(Buffer.from("doc"), "f.doc", "doc");
    expect(result.attempts[0]).toContain("Windows");
    expect(result.method).toBe("word-com");
    expect(spawnSyncMock).toHaveBeenCalled();
    const firstSpawnArgs = spawnSyncMock.mock.calls[0]?.[1] as string[];
    expect(firstSpawnArgs).toContain("-w");
    expect(firstSpawnArgs).toContain("200");
  });
});
