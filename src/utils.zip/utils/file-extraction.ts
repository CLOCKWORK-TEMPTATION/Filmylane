/**
 * file-extraction.ts - منطق استخراج النصوص من الملفات (Server-side)
 * يدعم: txt, fountain, fdx, docx, pdf, doc
 */

import type {
  ExtractionMethod,
  FileExtractionResult,
  ImportedFileType,
} from "@/types/file-import";
import type { ScreenplayBlock } from "./document-model";
import {
  decodeScreenplayPayload,
  extractPayloadFromText,
  extractEncodedPayloadMarker,
} from "./document-model";
import {
  computeImportedTextQualityScore,
  normalizeDocTextFromAntiword,
  preprocessImportedTextForClassifier,
} from "./file-import-preprocessor";
import { extractTextWithMistralOcr, isMistralConfigured } from "./mistral-ocr";

type ExtractionCoreResult = {
  text: string;
  method: ExtractionMethod;
  usedOcr: boolean;
  warnings: string[];
  attempts: string[];
  qualityScore?: number;
  normalizationApplied?: string[];
  structuredBlocks?: FileExtractionResult["structuredBlocks"];
  payloadVersion?: number;
};

// ==================== Text/Fountain/FDX ====================

function normalizeNewlines(text: string): string {
  return text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
}

function normalizeExtractedText(text: string): string {
  return normalizeNewlines(text)
    .split("\u0000")
    .join("")
    .split("\u000B")
    .join("\n")
    .replace(/\f/g, "\n")
    .replace(/\u2028|\u2029/g, "\n")
    .replace(/^\uFEFF/, "");
}

const INLINE_SPEAKER_RE = /^([^:：]{1,30})\s*[:：]\s*(.+)$/u;
const SPEAKER_CUE_RE = /^([^:：]{1,30})\s*[:：]\s*$/u;
const SCENE_STATUS_SEGMENT_RE =
  /(?:نهار|ليل|صباح|مساء|داخلي|خارجي|داخل[يى]\s*[-/]\s*خارج[يى]|خارج[يى]\s*[-/]\s*داخل[يى])/iu;
const SCENE_TOP_LINE_RE = new RegExp(
  String.raw`^((?:مشهد|scene)\s*[0-9٠-٩]+)\s*(?:[-–—]\s*)?(${SCENE_STATUS_SEGMENT_RE.source}.+)$`,
  "iu"
);
const SCENE_HEADER_1_ONLY_RE = /^(?:مشهد|scene)\s*[0-9٠-٩]+(?:\s*[:：])?$/iu;
const TRANSITION_LINE_RE = /^(?:قطع|انتقال(?:\s+إلى)?|cut\s+to)\s*[:：]?$/iu;
const ACTION_START_RE =
  /^(?:يرفع|ينهض|يقف|تنتقل|تصدم|يتبادل|يبتسم|يصمت|تتركه|تتناول|يجلس|ترفع|تجلس|يدخل|وهو)\b/u;
const DIALOGUE_INLINE_ACTION_SPLIT_RE =
  /\s((?:و?(?:يقف|تقف|يرفع|ينهض|تنتقل|تصدم|يتبادل|يبتسم|يصمت|تتركه|تتناول|ترفع)|وتقف).+)$/u;
const ACTION_INLINE_ACTION_SPLIT_RE =
  /\s((?:و?(?:ترفع|ينهض|تنتقل|تصدم|يتبادل|يبتسم|يصمت|تتركه|تتناول)).+)$/u;

const normalizeInlineSpaces = (value: string): string =>
  value.replace(/\s+/g, " ").trim();

const normalizeOcrArabicArtifacts = (value: string): string => {
  return value
    .replace(/^بس\s*م\b/iu, "بسم")
    .replace(/\bاهلل\b/gu, "الله")
    .replace(/\bالرمحن\b/gu, "الرحمن")
    .replace(/\bالرحمي\b/gu, "الرحيم")
    .replace(/\s*-\s*/g, " - ")
    .replace(/\s+/g, " ")
    .trim();
};

const isLikelySpeakerName = (value: string): boolean => {
  const name = normalizeInlineSpaces(value);
  if (!name || name.length > 28) return false;
  if (name.split(" ").length > 4) return false;
  if (!/^[\p{L}\p{N}\s]+$/u.test(name)) return false;
  if (/^(?:مشهد|scene|قطع|انتقال|داخلي|خارجي)$/iu.test(name)) return false;
  return true;
};

const shouldMergeActionContinuation = (previous: string, current: string): boolean => {
  const prev = normalizeInlineSpaces(previous);
  const curr = normalizeInlineSpaces(current);
  if (!prev || !curr) return false;
  if (SCENE_TOP_LINE_RE.test(curr) || SCENE_HEADER_1_ONLY_RE.test(curr)) return false;
  if (INLINE_SPEAKER_RE.test(curr) || SPEAKER_CUE_RE.test(curr)) return false;
  if (TRANSITION_LINE_RE.test(curr)) return false;
  if (/^(?:\.{3}|…|،|(?:و|ثم|ف)|الاخرى|بجوار|كل|يشتريني|بالك|بأربعة|العيشة|فيكوا|بسيط|ابويا)\b/u.test(curr))
    return true;
  if (prev.length >= 70 && curr.length <= 90 && !ACTION_START_RE.test(curr))
    return true;
  return false;
};

const shouldMergeDialogueContinuation = (
  previous: string,
  current: string
): boolean => {
  const prev = normalizeInlineSpaces(previous);
  const curr = normalizeInlineSpaces(current);
  if (!prev || !curr) return false;
  if (SCENE_TOP_LINE_RE.test(curr) || SCENE_HEADER_1_ONLY_RE.test(curr)) return false;
  if (INLINE_SPEAKER_RE.test(curr) || SPEAKER_CUE_RE.test(curr)) return false;
  if (TRANSITION_LINE_RE.test(curr)) return false;
  if (ACTION_START_RE.test(curr)) return false;
  if (/^(?:\.{3}|…|،|(?:و|ثم|ف)|يا|كل|يشتريني|بالك|بأربعة|العيشة|فيكوا|بسيط|ابويا)\b/u.test(curr))
    return true;
  return !/[.!؟?!…]\s*$/u.test(prev);
};

const buildStructuredBlocksFromNormalizedText = (
  text: string
): ScreenplayBlock[] => {
  const lines = normalizeExtractedText(text)
    .split("\n")
    .map((line) => normalizeOcrArabicArtifacts(normalizeInlineSpaces(line)))
    .filter(Boolean);

  const blocks: ScreenplayBlock[] = [];
  let expectingSceneHeader3 = false;
  let expectingDialogueAfterCue = false;

  const pushBlock = (formatId: ScreenplayBlock["formatId"], lineText: string) => {
    if (!lineText) return;
    blocks.push({ formatId, text: lineText });
  };

  for (const line of lines) {
    if (/^بسم\b/u.test(line) || /^بسم الله/u.test(line)) {
      pushBlock("basmala", line);
      expectingSceneHeader3 = false;
      expectingDialogueAfterCue = false;
      continue;
    }

    const topLineMatch = line.match(SCENE_TOP_LINE_RE);
    if (topLineMatch) {
      pushBlock("scene-header-1", normalizeInlineSpaces(topLineMatch[1] ?? ""));
      pushBlock("scene-header-2", normalizeInlineSpaces(topLineMatch[2] ?? ""));
      expectingSceneHeader3 = true;
      expectingDialogueAfterCue = false;
      continue;
    }

    if (SCENE_HEADER_1_ONLY_RE.test(line)) {
      pushBlock("scene-header-1", line.replace(/[:：]\s*$/u, "").trim());
      expectingSceneHeader3 = true;
      expectingDialogueAfterCue = false;
      continue;
    }

    if (expectingSceneHeader3) {
      if (!TRANSITION_LINE_RE.test(line) && !INLINE_SPEAKER_RE.test(line)) {
        pushBlock("scene-header-3", line);
        expectingSceneHeader3 = false;
        expectingDialogueAfterCue = false;
        continue;
      }
      expectingSceneHeader3 = false;
    }

    if (TRANSITION_LINE_RE.test(line)) {
      pushBlock("transition", line);
      expectingDialogueAfterCue = false;
      continue;
    }

    const cueOnlyMatch = line.match(SPEAKER_CUE_RE);
    if (cueOnlyMatch && isLikelySpeakerName(cueOnlyMatch[1] ?? "")) {
      pushBlock("character", `${normalizeInlineSpaces(cueOnlyMatch[1] ?? "")}:`);
      expectingDialogueAfterCue = true;
      continue;
    }

    const inlineSpeakerMatch = line.match(INLINE_SPEAKER_RE);
    if (inlineSpeakerMatch && isLikelySpeakerName(inlineSpeakerMatch[1] ?? "")) {
      pushBlock("character", `${normalizeInlineSpaces(inlineSpeakerMatch[1] ?? "")}:`);
      pushBlock("dialogue", normalizeInlineSpaces(inlineSpeakerMatch[2] ?? ""));
      expectingDialogueAfterCue = false;
      continue;
    }

    const lastBlock = blocks[blocks.length - 1];
    if (expectingDialogueAfterCue && lastBlock?.formatId === "character") {
      pushBlock("dialogue", line);
      expectingDialogueAfterCue = false;
      continue;
    }

    if (lastBlock?.formatId === "dialogue") {
      if (shouldMergeDialogueContinuation(lastBlock.text, line)) {
        lastBlock.text = `${lastBlock.text} ${line}`.replace(/\s+/g, " ").trim();
        continue;
      }
    }

    if (lastBlock?.formatId === "action") {
      if (shouldMergeActionContinuation(lastBlock.text, line)) {
        lastBlock.text = `${lastBlock.text} ${line}`.replace(/\s+/g, " ").trim();
        continue;
      }
    }

    pushBlock("action", line);
    expectingDialogueAfterCue = false;
  }

  const expandedBlocks: ScreenplayBlock[] = [];
  for (const block of blocks) {
    if (block.formatId === "dialogue") {
      const match = block.text.match(DIALOGUE_INLINE_ACTION_SPLIT_RE);
      const actionTail = normalizeInlineSpaces(match?.[1] ?? "");
      const dialogueText = normalizeInlineSpaces(
        match ? block.text.slice(0, match.index).trim() : block.text
      );
      if (actionTail && dialogueText.length >= 3 && actionTail.length >= 12) {
        expandedBlocks.push({ formatId: "dialogue", text: dialogueText });
        expandedBlocks.push({ formatId: "action", text: actionTail });
        continue;
      }
    }

    if (block.formatId === "action") {
      const match = block.text.match(ACTION_INLINE_ACTION_SPLIT_RE);
      const actionTail = normalizeInlineSpaces(match?.[1] ?? "");
      const actionHead = normalizeInlineSpaces(
        match ? block.text.slice(0, match.index).trim() : block.text
      );
      if (actionTail && actionHead.length >= 60 && actionTail.length >= 20) {
        expandedBlocks.push({ formatId: "action", text: actionHead });
        expandedBlocks.push({ formatId: "action", text: actionTail });
        continue;
      }
    }

    expandedBlocks.push(block);
  }

  return expandedBlocks;
};

function extractTextFromBuffer(buffer: Buffer): string {
  const utf8Text = buffer.toString("utf-8");
  const hasReplacementChars =
    utf8Text.includes("\uFFFD") || utf8Text.includes("�");
  if (!hasReplacementChars) return normalizeNewlines(utf8Text);

  try {
    // eslint-disable-next-line @typescript-eslint/no-require-imports
    const iconv = require("iconv-lite");
    const win1256Text = iconv.decode(buffer, "windows-1256") as string;
    if (win1256Text && !win1256Text.includes("\uFFFD")) {
      return normalizeNewlines(win1256Text);
    }
  } catch {
    // pass
  }

  return normalizeNewlines(buffer.toString("latin1"));
}

const payloadToExtractionResult = (
  payload: NonNullable<ReturnType<typeof extractPayloadFromText>>,
  attempts: string[],
  warnings: string[]
): ExtractionCoreResult => {
  return {
    text: payload.blocks.map((block) => block.text).join("\n"),
    method: "app-payload",
    usedOcr: false,
    warnings,
    attempts,
    qualityScore: 1,
    normalizationApplied: ["payload-direct-restore"],
    structuredBlocks: payload.blocks,
    payloadVersion: payload.version,
  };
};

// ==================== DOCX ====================

async function extractTextFromDocx(buffer: Buffer): Promise<ExtractionCoreResult> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const mammoth = (await import("mammoth")) as any;
  const extractRawText =
    mammoth.extractRawText || mammoth.default?.extractRawText;
  const result = await extractRawText({ buffer });
  const text = normalizeExtractedText(result.value as string);
  const payload = extractPayloadFromText(text);
  if (payload) {
    return payloadToExtractionResult(payload, ["mammoth", "payload-marker"], []);
  }

  const preprocessed = preprocessImportedTextForClassifier(text, "docx");
  const structuredBlocks = buildStructuredBlocksFromNormalizedText(
    preprocessed.text
  );
  return {
    text: preprocessed.text,
    method: "mammoth",
    usedOcr: false,
    warnings: [],
    attempts: ["mammoth"],
    qualityScore: computeImportedTextQualityScore(preprocessed.text),
    normalizationApplied: preprocessed.applied,
    structuredBlocks:
      structuredBlocks.length > 0 ? structuredBlocks : undefined,
  };
}

// ==================== PDF ====================

async function extractPayloadFromPdfMetadata(
  buffer: Buffer
): Promise<ReturnType<typeof decodeScreenplayPayload>> {
  try {
    const { PDFDocument } = await import("pdf-lib");
    const documentRef = await PDFDocument.load(buffer, {
      ignoreEncryption: true,
    });
    const candidates = [
      documentRef.getSubject() ?? "",
      ...(documentRef.getKeywords() ?? []),
      documentRef.getTitle() ?? "",
      documentRef.getProducer() ?? "",
    ];

    for (const candidate of candidates) {
      if (!candidate) continue;
      const encoded = extractEncodedPayloadMarker(candidate);
      if (!encoded) continue;
      const payload = decodeScreenplayPayload(encoded);
      if (payload) return payload;
    }
  } catch {
    // ignore metadata failures
  }

  return null;
}

async function extractPdfLocalText(buffer: Buffer): Promise<string> {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const pdfParse = (await import("pdf-parse")) as any;
  const parser = new pdfParse.PDFParse({
    data: new Uint8Array(buffer),
    useSystemFonts: true,
    disableFontFace: true,
    disableWorker: true,
    isEvalSupported: false,
  });

  try {
    const textResult = await parser.getText();
    return normalizeExtractedText((textResult?.text ?? "") as string);
  } finally {
    try {
      await parser.destroy();
    } catch {
      // ignore
    }
  }
}

async function extractTextFromPdf(
  buffer: Buffer,
  filename: string
): Promise<ExtractionCoreResult> {
  const warnings: string[] = [];
  const attempts: string[] = [];
  const MIN_TEXT_DENSITY = 20;

  const metadataPayload = await extractPayloadFromPdfMetadata(buffer);
  attempts.push("pdf-metadata");
  if (metadataPayload) {
    return payloadToExtractionResult(metadataPayload, attempts, warnings);
  }

  try {
    attempts.push("pdf-local");
    const localText = await extractPdfLocalText(buffer);
    const textPayload = extractPayloadFromText(localText);
    if (textPayload) {
      return payloadToExtractionResult(textPayload, attempts, warnings);
    }

    const preprocessed = preprocessImportedTextForClassifier(localText, "pdf");
    const qualityScore = computeImportedTextQualityScore(preprocessed.text);
    if (preprocessed.text.trim().length >= MIN_TEXT_DENSITY && qualityScore >= 0.45) {
      const structuredBlocks = buildStructuredBlocksFromNormalizedText(
        preprocessed.text
      );
      return {
        text: preprocessed.text,
        method: "pdf-local",
        usedOcr: false,
        warnings,
        attempts,
        qualityScore,
        normalizationApplied: preprocessed.applied,
        structuredBlocks:
          structuredBlocks.length > 0 ? structuredBlocks : undefined,
      };
    }

    warnings.push(
      `النص المحلي ضعيف (quality=${qualityScore.toFixed(3)}، ${localText.length} حرف)، سيتم التحويل إلى OCR`
    );
  } catch (error) {
    warnings.push(
      `فشل parser المحلي: ${error instanceof Error ? error.message : "خطأ غير معروف"}`
    );
  }

  attempts.push("ocr-mistral");
  if (!isMistralConfigured()) {
    warnings.push(
      "MISTRAL_API_KEY غير معرّف. لم يتم تشغيل OCR. أضف المفتاح لاستخراج النص من ملفات PDF الممسوحة."
    );
    throw new Error(`فشل استخراج نص من PDF.\nالتحذيرات:\n${warnings.join("\n")}`);
  }

  try {
    const ocrText = normalizeExtractedText(
      await extractTextWithMistralOcr(buffer, filename)
    );
    const preprocessed = preprocessImportedTextForClassifier(ocrText, "pdf");
    const structuredBlocks = buildStructuredBlocksFromNormalizedText(
      preprocessed.text
    );
    return {
      text: preprocessed.text,
      method: "ocr-mistral",
      usedOcr: true,
      warnings,
      attempts,
      qualityScore: computeImportedTextQualityScore(preprocessed.text),
      normalizationApplied: preprocessed.applied,
      structuredBlocks:
        structuredBlocks.length > 0 ? structuredBlocks : undefined,
    };
  } catch (error) {
    warnings.push(
      `فشل Mistral OCR: ${error instanceof Error ? error.message : "خطأ غير معروف"}`
    );
    throw new Error(`فشل استخراج نص من PDF.\nالتحذيرات:\n${warnings.join("\n")}`, {
      cause: error,
    });
  }
}

// ==================== DOC ====================

async function extractTextFromDoc(
  buffer: Buffer,
  filename: string
): Promise<ExtractionCoreResult> {
  const warnings: string[] = [];
  const attempts: string[] = [];

  const { writeFileSync, unlinkSync, existsSync, mkdtempSync, rmSync } =
    await import("fs");
  const { join } = await import("path");
  const { tmpdir } = await import("os");
  const { execSync, spawnSync } = await import("child_process");

  const toWslPath = (windowsPath: string): string =>
    windowsPath
      .replace(/\\/g, "/")
      .replace(/^([A-Za-z]):/, (_m, drive: string) => `/mnt/${drive.toLowerCase()}`);

  const runAntiwordNative = (
    binaryPath: string,
    targetPath: string,
    resourcesPath?: string
  ): string => {
    const env = {
      ...process.env,
      ...(resourcesPath ? { ANTIWORDHOME: resourcesPath } : {}),
    };
    const withUtf8 = spawnSync(
      binaryPath,
      ["-m", "UTF-8.txt", "-w", "200", targetPath],
      {
        encoding: "utf-8",
        timeout: 30_000,
        env,
        windowsHide: true,
      }
    );
    if (withUtf8.status === 0) {
      return withUtf8.stdout || "";
    }
    const fallback = spawnSync(binaryPath, ["-w", "200", targetPath], {
      encoding: "utf-8",
      timeout: 30_000,
      env,
      windowsHide: true,
    });
    if (fallback.status !== 0) {
      throw new Error(
        (fallback.stderr || withUtf8.stderr || "antiword native failed").trim()
      );
    }
    return fallback.stdout || "";
  };

  const runAntiwordViaWsl = (
    binaryWslPath: string,
    targetWslPath: string,
    resourcesWslPath?: string
  ): string => {
    const withUtf8 = resourcesWslPath
      ? `wsl env ANTIWORDHOME="${resourcesWslPath}" "${binaryWslPath}" -m UTF-8.txt -w 200 "${targetWslPath}"`
      : `wsl "${binaryWslPath}" -m UTF-8.txt -w 200 "${targetWslPath}"`;
    try {
      return execSync(withUtf8, { encoding: "utf-8", timeout: 30_000 });
    } catch {
      const fallback = resourcesWslPath
        ? `wsl env ANTIWORDHOME="${resourcesWslPath}" "${binaryWslPath}" -w 200 "${targetWslPath}"`
        : `wsl "${binaryWslPath}" -w 200 "${targetWslPath}"`;
      return execSync(fallback, { encoding: "utf-8", timeout: 30_000 });
    }
  };

  const tempDir = mkdtempSync(join(tmpdir(), "doc-extract-"));
  const tempFilePath = join(tempDir, filename);
  writeFileSync(tempFilePath, buffer);

  const pythonExecEnv = {
    ...process.env,
    PYTHONIOENCODING: "utf-8",
    PYTHONUTF8: "1",
  };

  const cleanup = () => {
    try {
      if (existsSync(tempFilePath)) unlinkSync(tempFilePath);
      rmSync(tempDir, { recursive: true, force: true });
    } catch {
      // best effort
    }
  };

  try {
    const bundledAntiwordExe = join(
      process.cwd(),
      ".tools",
      "antiword-app",
      "bin",
      "antiword.exe"
    );
    const bundledAntiwordLinux = join(
      process.cwd(),
      ".tools",
      "antiword-app",
      "bin",
      "antiword"
    );
    const bundledResourcesWin = join(
      process.cwd(),
      ".tools",
      "antiword-app",
      "Resources"
    );
    const docWslPath = toWslPath(tempFilePath);

    const antiwordCandidates: Array<
      | {
          label: string;
          mode: "native";
          binaryPath: string;
          resourcesPath?: string;
        }
      | {
          label: string;
          mode: "wsl";
          binaryWslPath: string;
          resourcesWslPath?: string;
          requiredWindowsBinaryPath?: string;
        }
    > = [
      {
        label: "antiword (نسخة التطبيق المدمجة - Windows)",
        mode: "native",
        binaryPath: bundledAntiwordExe,
        resourcesPath: bundledResourcesWin,
      },
      {
        label: "antiword (نسخة التطبيق المدمجة - WSL Linux)",
        mode: "wsl",
        binaryWslPath: toWslPath(bundledAntiwordLinux),
        resourcesWslPath: toWslPath(bundledResourcesWin),
        requiredWindowsBinaryPath: bundledAntiwordLinux,
      },
      {
        label: "antiword (WSL /usr/bin/antiword)",
        mode: "wsl",
        binaryWslPath: "/usr/bin/antiword",
      },
    ];

    let bestLowQualityAntiword: ExtractionCoreResult | null = null;

    for (const candidate of antiwordCandidates) {
      attempts.push(candidate.label);
      try {
        if (candidate.mode === "native" && !existsSync(candidate.binaryPath)) {
          warnings.push(`${candidate.label}: binary غير موجود (${candidate.binaryPath})`);
          continue;
        }
        if (
          candidate.mode === "wsl" &&
          candidate.requiredWindowsBinaryPath &&
          !existsSync(candidate.requiredWindowsBinaryPath)
        ) {
          warnings.push(
            `${candidate.label}: binary غير موجود (${candidate.requiredWindowsBinaryPath})`
          );
          continue;
        }

        const output =
          candidate.mode === "native"
            ? runAntiwordNative(
                candidate.binaryPath,
                tempFilePath,
                candidate.resourcesPath
              )
            : runAntiwordViaWsl(
                candidate.binaryWslPath,
                docWslPath,
                candidate.resourcesWslPath
              );

        if (output.trim().length === 0) {
          warnings.push(`${candidate.label}: أعاد نصًا فارغًا`);
          continue;
        }

        const normalized = normalizeDocTextFromAntiword(
          normalizeExtractedText(output)
        );
        const qualityScore = computeImportedTextQualityScore(normalized.text);

        if (qualityScore >= 0.72) {
          const structuredBlocks = buildStructuredBlocksFromNormalizedText(
            normalized.text
          );
          return {
            text: normalized.text,
            method: "antiword",
            usedOcr: false,
            warnings,
            attempts,
            qualityScore,
            normalizationApplied: normalized.applied,
            structuredBlocks:
              structuredBlocks.length > 0 ? structuredBlocks : undefined,
          };
        }

        warnings.push(
          `${candidate.label}: quality منخفض (${qualityScore.toFixed(3)}) - الانتقال إلى fallback أعلى جودة`
        );
        if (!bestLowQualityAntiword) {
          const structuredBlocks = buildStructuredBlocksFromNormalizedText(
            normalized.text
          );
          bestLowQualityAntiword = {
            text: normalized.text,
            method: "antiword",
            usedOcr: false,
            warnings: [...warnings],
            attempts: [...attempts],
            qualityScore,
            normalizationApplied: normalized.applied,
            structuredBlocks:
              structuredBlocks.length > 0 ? structuredBlocks : undefined,
          };
        }
      } catch (error) {
        warnings.push(
          `${candidate.label}: ${error instanceof Error ? error.message : "فشل"}`
        );
      }
    }

    // Word COM direct text
    try {
      attempts.push("Word COM automation (نص مباشر)");
      const pyScript = `
import sys
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    import win32com.client
    word = win32com.client.Dispatch("Word.Application")
    word.Visible = False
    doc = word.Documents.Open(r"${tempFilePath.replace(/\\/g, "\\\\")}")
    text = doc.Content.Text
    doc.Close(False)
    word.Quit()
    sys.stdout.write(text)
except Exception as e:
    sys.stderr.write(f"ERROR: {e}\\n")
    sys.exit(1)
`;
      const pyTempPath = join(tempDir, "extract_doc.py");
      writeFileSync(pyTempPath, pyScript, "utf-8");
      const output = execSync(`python "${pyTempPath}"`, {
        encoding: "utf-8",
        timeout: 60_000,
        env: pythonExecEnv,
      });
      if (output.trim().length > 0) {
        const preprocessed = preprocessImportedTextForClassifier(
          normalizeExtractedText(output),
          "doc"
        );
        const structuredBlocks = buildStructuredBlocksFromNormalizedText(
          preprocessed.text
        );
        return {
          text: preprocessed.text,
          method: "word-com",
          usedOcr: false,
          warnings,
          attempts,
          qualityScore: computeImportedTextQualityScore(preprocessed.text),
          normalizationApplied: preprocessed.applied,
          structuredBlocks:
            structuredBlocks.length > 0 ? structuredBlocks : undefined,
        };
      }
      warnings.push("Word COM (نص): أعاد نصًا فارغًا");
    } catch (error) {
      warnings.push(
        `Word COM (نص): ${error instanceof Error ? error.message : "فشل"}`
      );
    }

    // Word COM -> PDF -> OCR
    if (isMistralConfigured()) {
      try {
        attempts.push("Word COM → PDF → OCR");
        const pdfTempPath = join(tempDir, "converted.pdf");
        const pyScript = `
import sys
try:
    import win32com.client
    word = win32com.client.Dispatch("Word.Application")
    word.Visible = False
    doc = word.Documents.Open(r"${tempFilePath.replace(/\\/g, "\\\\")}")
    doc.SaveAs2(r"${pdfTempPath.replace(/\\/g, "\\\\")}", FileFormat=17)
    doc.Close(False)
    word.Quit()
except Exception as e:
    print(f"ERROR: {e}", file=sys.stderr)
    sys.exit(1)
`;
        const pyTempPath = join(tempDir, "convert_to_pdf.py");
        writeFileSync(pyTempPath, pyScript, "utf-8");
        execSync(`python "${pyTempPath}"`, {
          encoding: "utf-8",
          timeout: 60_000,
          env: pythonExecEnv,
        });
        if (existsSync(pdfTempPath)) {
          const { readFileSync } = await import("fs");
          const pdfBuffer = readFileSync(pdfTempPath);
          const ocrText = normalizeExtractedText(
            await extractTextWithMistralOcr(pdfBuffer, "converted.pdf")
          );
          const preprocessed = preprocessImportedTextForClassifier(
            ocrText,
            "doc"
          );
          const structuredBlocks = buildStructuredBlocksFromNormalizedText(
            preprocessed.text
          );
          return {
            text: preprocessed.text,
            method: "ocr-mistral",
            usedOcr: true,
            warnings,
            attempts,
            qualityScore: computeImportedTextQualityScore(preprocessed.text),
            normalizationApplied: preprocessed.applied,
            structuredBlocks:
              structuredBlocks.length > 0 ? structuredBlocks : undefined,
          };
        }
        warnings.push("Word COM → PDF: لم يتم إنشاء ملف PDF");
      } catch (error) {
        warnings.push(
          `Word COM → PDF → OCR: ${error instanceof Error ? error.message : "فشل"}`
        );
      }
    } else {
      warnings.push(
        "MISTRAL_API_KEY غير معرّف. تم تخطي مسار Word COM → PDF → OCR."
      );
    }

    if (bestLowQualityAntiword) {
      warnings.push(
        "تم الإرجاع من antiword بجودة منخفضة بعد فشل كل المسارات الأعلى جودة."
      );
      return {
        ...bestLowQualityAntiword,
        warnings,
        attempts,
      };
    }

    throw new Error(
      `فشل استخراج نص من ملف .doc بعد ${attempts.length} محاولة.\n` +
        `المحاولات:\n${attempts.map((a, i) => `  ${i + 1}. ${a}`).join("\n")}\n` +
        `التحذيرات:\n${warnings.map((w) => `  - ${w}`).join("\n")}`
    );
  } finally {
    cleanup();
  }
}

// ==================== Main ====================

export async function extractFileText(
  buffer: Buffer,
  filename: string,
  fileType: ImportedFileType
): Promise<FileExtractionResult> {
  switch (fileType) {
    case "txt":
    case "fountain":
    case "fdx": {
      const text = normalizeExtractedText(extractTextFromBuffer(buffer));
      return {
        text,
        fileType,
        method: "native-text",
        usedOcr: false,
        warnings: [],
        attempts: ["native-text"],
        qualityScore: computeImportedTextQualityScore(text),
      };
    }

    case "docx": {
      const result = await extractTextFromDocx(buffer);
      return {
        ...result,
        text: normalizeExtractedText(result.text),
        fileType,
      };
    }

    case "pdf": {
      const result = await extractTextFromPdf(buffer, filename);
      return {
        ...result,
        text: normalizeExtractedText(result.text),
        fileType,
      };
    }

    case "doc": {
      const result = await extractTextFromDoc(buffer, filename);
      return {
        ...result,
        text: normalizeExtractedText(result.text),
        fileType,
      };
    }

    default:
      throw new Error(`نوع الملف غير مدعوم: ${fileType}`);
  }
}
